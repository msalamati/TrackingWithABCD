# TrackingWithABCD

This is a draft of the paper on ABCD for tracking a nominal open loop trajectory. Possible future extension is to utilize the control inputs provided by a nominal closed loop controller.